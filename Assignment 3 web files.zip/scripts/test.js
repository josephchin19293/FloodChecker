function testModule() {
  this.testFunction = function() {
    console.log("hello world!")
  }
}
