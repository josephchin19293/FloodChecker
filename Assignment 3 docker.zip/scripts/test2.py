import base64todecimal

print(base64todecimal.base64todecimal('BZM='))
